# ADRIY Gaya Video (skill)

Paket skill berisi 10 gaya video pendek edukasi 9:16 di Remotion untuk kanal ADRIY. Bacalah `SKILL.md` lebih dulu.

**Cara memasang di Claude:**
- **claude.ai:** Settings → Capabilities → Skills → unggah file ZIP ini.
- **Claude Code:** ekstrak ke `.claude/skills/adriy-gaya-video/` di proyek (atau di `~/.claude/skills/` supaya berlaku di semua proyek).
