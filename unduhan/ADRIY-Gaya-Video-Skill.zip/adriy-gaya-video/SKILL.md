---
name: adriy-gaya-video
description: Membuat video pendek edukasi 9:16 di Remotion dengan 10 gaya baku ADRIY yang sudah disetujui pemilik kanal (Anatomical 3D, Cosmic Motion, Scientific 3D, Exploded View, Flat Design 2.0, Mixed Media Documentary, Paper Cutout, Indonesian Wayang, Documentary Motion, Realistic 3D). Gunakan saat diminta membuat video, gambar contoh, atau adegan Remotion untuk kanal ADRIY. Skill ini memilihkan gaya sesuai topik dan menyediakan panduan lengkap, kode komponen siap pakai, font, arsip domain publik, dan efek suara.
---

# ADRIY Gaya Video — 10 Gaya Baku

Semua gaya di sini **sudah disetujui pemilik kanal**. Pertahankan bentuk, detail, palet, tipografi, dan geraknya **persis** seperti panduan dan contohnya. Pakai ulang kode yang ada, jangan membuat gaya baru dari nol.

## 1. Pilih gaya sesuai topik

| Topik | Gaya | Panduan | Kode acuan |
|---|---|---|---|
| Tubuh manusia, organ | Anatomical 3D | `gaya/GAYA-ADRIY-ANATOMICAL-3D.md` | `kode/src/` (video jantung) |
| Luar angkasa, planet, galaksi | Cosmic Motion | `gaya/GAYA-ADRIY-COSMIC-MOTION.md` | `kode/contoh-gaya/cosmic/` |
| Molekul, kimia, DNA, sel | Scientific 3D | `gaya/GAYA-ADRIY-SCIENTIFIC-3D.md` | `kode/contoh-gaya/scientific/` |
| Bedah gadget, mesin, alat | Exploded View (+ tur kamera masuk-keluar) | `gaya/GAYA-ADRIY-EXPLODED-VIEW.md` | `kode/contoh-gaya/exploded/` |
| Explainer, infografik, tips | Flat Design 2.0 | `gaya/GAYA-ADRIY-FLAT-DESIGN.md` | `kode/contoh-gaya/flat/` |
| Sejarah, penemuan, fakta unik, makanan, perbandingan (kolase) | Mixed Media Documentary | `gaya/GAYA-ADRIY-MIXED-MEDIA.md` | `kode/contoh-gaya/mixed/` |
| Alam, geografi, ekosistem, siklus hidup | Paper Cutout | `gaya/GAYA-ADRIY-PAPER-CUTOUT.md` | `kode/contoh-gaya/paper/` |
| Wayang, legenda, epos, budaya Nusantara | Indonesian Wayang | `gaya/GAYA-ADRIY-WAYANG.md` | `kode/contoh-gaya/wayang/` |
| Peristiwa sejarah dan tokoh (sinematik, satu foto) | Documentary Motion | `gaya/GAYA-ADRIY-DOCUMENTARY-MOTION.md` | `kode/contoh-gaya/dokumenter/` |
| Material dan benda nyata (logam, permata, es) | Realistic 3D | `gaya/GAYA-ADRIY-REALISTIC-3D.md` | `kode/contoh-gaya/realistic/` |

Lihat juga `contoh-gambar/` untuk hasil yang sudah disetujui. Kalau ragu memilih antara dua gaya, tanyakan ke pemilik.

## 2. Cara memakai
1. **Baca panduan gaya** yang dipilih sampai habis sebelum menulis kode.
2. **Salin isi folder `kode/` ke akar proyek Remotion** (Remotion 4.0.242, React 18.3.1, three 0.169, @react-three/fiber 8.17.10). Susunannya sama dengan proyek asli (`src/`, `contoh-gaya/`, `public/`), sehingga impor seperti `../../src/components/Teks` langsung jalan. Lalu jalankan `npm install`.
3. **Buat komposisi baru** dengan memakai ulang `pustaka.tsx` gaya itu. Contoh episode dipakai sebagai pola susunan dan gerak.
4. **Render gambar uji:** `npx remotion still contoh-gaya/<gaya>/index.ts <Komposisi> out/x.png --frame=N`. Lihat hasilnya, lalu perbaiki teks yang bertumpuk, objek yang terpotong, atau label yang meleset sebelum diserahkan.
5. **Render video** bila diminta. Tanpa GPU, render 3D lambat, jadi pakai `--scale=0.5` untuk pratinjau, atau render di GitHub Actions atau komputer ber-GPU.

## 3. Aturan umum semua gaya
- **Format:** 9:16, 1080×1920, 30 fps.
- **Deterministik:** semua gerak dihitung dari `useCurrentFrame()` atau `spring`, tanpa `Math.random()`.
- **Font lokal** di `public/font`: Poppins, Playfair Display, Anton, dan Caveat. Font dimuat dengan `FontFace` dan `delayRender`. Jangan memakai Google Fonts daring.
- **3D** memakai `ThreeCanvas` dari `@remotion/three`, tanpa `@react-three/drei`.
- **Jangan kartun:** pemilik menolak garis luar tebal dan warna rata ala kartun. Utamakan detail, kedalaman, dan bahan yang meyakinkan.
- **Arsip asli** (Mixed Media, Wayang, Documentary):
  - Hanya berkas berstatus domain publik atau CC0 dari Wikimedia Commons, dan CC BY dengan kredit di layar.
  - Ambil lewat API dengan User-Agent deskriptif dan jeda antar-permintaan, karena Commons sering membalas 429.
  - Catat setiap berkas di `public/arsip/SUMBER.md`.
- **Fakta:** pakai sumber tepercaya, cantumkan sumber di layar, tulis "±" untuk perkiraan, dan beri catatan "ilustrasi" atau "tidak sesuai skala" bila perlu.
- **Ruang kosong:** teks tidak boleh menutupi inti gambar. Satu pesan utama per adegan.

## 4. Isi paket
- `gaya/`: 10 panduan gaya lengkap (palet, tipografi, komposisi, gerak, aturan isi).
- `kode/src/`: video "Cara Kerja Jantung" (Anatomical 3D) beserta komponen `Latar`, `Teks`, `Overlay`, `Maskot`, `Audio`, dan model organ prosedural.
- `kode/contoh-gaya/<gaya>/`: `pustaka.tsx` (komponen) dan contoh episode untuk 9 gaya lain.
- `kode/public/`:
  - `font/`: font lokal
  - `arsip/`: arsip domain publik beserta `SUMBER.md`, dan wayang transparan di `arsip/wayang/`
  - `sfx/` dan `musik/`: efek suara dan musik buatan sendiri, bebas hak cipta
- `kode/package.json`, `remotion.config.ts`, `tsconfig.json`: konfigurasi proyek. `remotion.config.ts` sudah memakai renderer WebGL `swangle` untuk server tanpa GPU.
- `contoh-gambar/`: gambar acuan yang disetujui untuk tiap gaya, ditambah lembar gerak kamera Exploded View dan storyboard gerak Mixed Media.
